import express from "express";
import crypto from "node:crypto";
import { db } from "../db.js";

const router = express.Router();

/* ===============================
   CRIA TABELAS SE NÃO EXISTIREM
================================ */

db.exec(`
CREATE TABLE IF NOT EXISTS quotes (
  id TEXT PRIMARY KEY,
  client_id TEXT,
  client_name TEXT,
  status TEXT DEFAULT 'pending',
  subtotal REAL DEFAULT 0,
  tax_total REAL DEFAULT 0,
  discount_total REAL DEFAULT 0,
  total_value REAL DEFAULT 0,
  created_at INTEGER,
  updated_at INTEGER
);

CREATE TABLE IF NOT EXISTS quote_items (
  id TEXT PRIMARY KEY,
  quote_id TEXT,
  product_id TEXT,
  code TEXT,
  description TEXT,
  unit TEXT,
  quantity REAL,
  unit_price REAL,
  total_price REAL,
  icms REAL DEFAULT 0,
  issqn REAL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_quote_items_quote
ON quote_items(quote_id);
`);

/* ===============================
   CALCULAR TOTAIS
================================ */

function calcTotals(items = []) {

  let subtotal = 0;
  let tax = 0;

  for (const item of items) {

    const total = Number(item.total_price || 0);
    subtotal += total;

    const icms = Number(item.icms || 0);
    const issqn = Number(item.issqn || 0);

    tax += total * ((icms + issqn) / 100);

  }

  return {
    subtotal,
    tax_total: tax,
    total_value: subtotal + tax
  };

}

/* ===============================
   LISTAR COTAÇÕES
================================ */

router.get("/", (req, res) => {

  const rows = db.prepare(`
    SELECT *
    FROM quotes
    ORDER BY created_at DESC
  `).all();

  res.json(rows);

});

/* ===============================
   BUSCAR UMA COTAÇÃO
================================ */

router.get("/:id", (req, res) => {

  const id = req.params.id;

  const quote = db.prepare(`
    SELECT *
    FROM quotes
    WHERE id = ?
  `).get(id);

  if (!quote) {
    return res.status(404).json({ error: "Cotação não encontrada" });
  }

  const items = db.prepare(`
    SELECT *
    FROM quote_items
    WHERE quote_id = ?
  `).all(id);

  quote.items = items;

  res.json(quote);

});

/* ===============================
   CRIAR COTAÇÃO
================================ */

router.post("/", (req, res) => {

  const data = req.body || {};
  const id = crypto.randomUUID();

  const items = Array.isArray(data.items) ? data.items : [];

  const totals = calcTotals(items);
  const now = Date.now();

  const trx = db.transaction(() => {

    db.prepare(`
      INSERT INTO quotes (
        id,
        client_id,
        client_name,
        subtotal,
        tax_total,
        total_value,
        created_at,
        updated_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      data.client_id || null,
      data.client_name || "",
      totals.subtotal,
      totals.tax_total,
      totals.total_value,
      now,
      now
    );

    const insertItem = db.prepare(`
      INSERT INTO quote_items (
        id,
        quote_id,
        product_id,
        code,
        description,
        unit,
        quantity,
        unit_price,
        total_price,
        icms,
        issqn
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const item of items) {

      insertItem.run(
        crypto.randomUUID(),
        id,
        item.product_id || null,
        item.code || "",
        item.description || "",
        item.unit || "un",
        Number(item.quantity || 0),
        Number(item.unit_price || 0),
        Number(item.total_price || 0),
        Number(item.icms || 0),
        Number(item.issqn || 0)
      );

    }

  });

  trx();

  res.json({ id });

});

/* ===============================
   ATUALIZAR COTAÇÃO
================================ */

router.put("/:id", (req, res) => {

  const id = req.params.id;
  const data = req.body || {};

  const items = Array.isArray(data.items) ? data.items : [];

  const totals = calcTotals(items);
  const now = Date.now();

  const trx = db.transaction(() => {

    db.prepare(`
      UPDATE quotes
      SET
        client_id = ?,
        client_name = ?,
        subtotal = ?,
        tax_total = ?,
        total_value = ?,
        updated_at = ?
      WHERE id = ?
    `).run(
      data.client_id || null,
      data.client_name || "",
      totals.subtotal,
      totals.tax_total,
      totals.total_value,
      now,
      id
    );

    db.prepare(`
      DELETE FROM quote_items
      WHERE quote_id = ?
    `).run(id);

    const insertItem = db.prepare(`
      INSERT INTO quote_items (
        id,
        quote_id,
        product_id,
        code,
        description,
        unit,
        quantity,
        unit_price,
        total_price,
        icms,
        issqn
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const item of items) {

      insertItem.run(
        crypto.randomUUID(),
        id,
        item.product_id || null,
        item.code || "",
        item.description || "",
        item.unit || "un",
        Number(item.quantity || 0),
        Number(item.unit_price || 0),
        Number(item.total_price || 0),
        Number(item.icms || 0),
        Number(item.issqn || 0)
      );

    }

  });

  trx();

  res.json({ ok: true });

});

/* ===============================
   APROVAR COTAÇÃO
================================ */

router.post("/:id/approve", (req, res) => {

  const id = req.params.id;

  db.prepare(`
    UPDATE quotes
    SET status = 'approved'
    WHERE id = ?
  `).run(id);

  res.json({ ok: true });

});

/* ===============================
   EXCLUIR COTAÇÃO
================================ */

router.delete("/:id", (req, res) => {

  const id = req.params.id;

  const trx = db.transaction(() => {

    db.prepare(`
      DELETE FROM quote_items
      WHERE quote_id = ?
    `).run(id);

    db.prepare(`
      DELETE FROM quotes
      WHERE id = ?
    `).run(id);

  });

  trx();

  res.json({ ok: true });

});

export default router;